# import os
# import django

# os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'online_store.settings')
# django.setup()

# from shop.models import Category, Brand, Product

# categories = [
#     "Electronics", "Clothing", "Home Appliances", "Beauty & Personal Care",
#     "Books", "Sports & Outdoors", "Furniture", "Toys & Games", "Automotive", "Grocery"
# ]

# brands = [
#     "Apple", "Samsung", "LG", "Sony", "Nike", "Adidas", "IKEA", "L’Oréal", "Hasbro", "Tesla"
# ]

# products = [
#     ("iPhone 15 Pro", "https://arabcomputers.com.sa/wp-content/uploads/2023/09/iPhone_15_Pro_Natural_Titanium_PDP_Image_Position-1__en-ME.jpg", "Latest iPhone Pro model with advanced features", 2999.99, "2025-01-01", 10, "Electronics", "Apple"),
#     ("Galaxy S23 Ultra", "https://images.samsung.com/is/image/samsung/assets/global/galaxy-s23-ultra.jpg", "Samsung’s top-tier flagship phone", 2499.50, "2024-11-10", 12, "Electronics", "Samsung"),
#     ("LG OLED TV 55", "https://www.lg.com/us/images/tvs/md07501485/gallery/desktop-01.jpg", "Ultra-thin OLED TV with vibrant colors", 1499.00, "2023-10-05", 7, "Electronics", "LG"),
#     ("Sony WH-1000XM5", "https://m.media-amazon.com/images/I/61bJcV3xa+L._AC_SL1500_.jpg", "Industry-leading noise canceling headphones", 499.99, "2024-01-15", 20, "Electronics", "Sony"),
#     ("Nike Air Max", "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/15baf1e3-2d1f-40de-9a3a-2c91ec82344a/air-max-270-shoes.png", "Comfortable and stylish running shoes", 199.99, "2023-03-20", 30, "Clothing", "Nike"),
#     ("Adidas Hoodie", "https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/83ac722ed3d24e88aa0aad1800b4ea86_9366/Essentials_3-Stripes_Hoodie_Grey_HS1455_01_laydown.jpg", "Soft fleece hoodie for everyday wear", 89.99, "2023-09-01", 25, "Clothing", "Adidas"),
#     ("IKEA Billy Bookcase", "https://www.ikea.com/us/en/images/products/billy-bookcase-white__0625599_pe692385_s5.jpg", "Classic white bookcase for your home", 99.99, "2022-12-05", 15, "Furniture", "IKEA"),
#     ("L’Oréal Face Cream", "https://www.lorealparisusa.com/-/media/project/loreal/brand-sites/oap/americas/us/products/skin-care/face-care/moisturizers/loreal-paris-revitalift-triple-power-anti-aging-moisturizer.jpg", "Revitalizing anti-aging moisturizer", 29.99, "2023-04-04", 50, "Beauty & Personal Care", "L’Oréal"),
#     ("Hasbro Monopoly", "https://m.media-amazon.com/images/I/81C5jzrZTJL.jpg", "Family-favorite classic board game", 39.99, "2024-05-15", 40, "Toys & Games", "Hasbro"),
#     ("Tesla Car Vacuum", "https://m.media-amazon.com/images/I/51l-jODNQWL.jpg", "Compact and efficient car vacuum", 129.99, "2023-06-06", 8, "Automotive", "Tesla"),
#     ("Organic Almonds 1kg", "https://images-na.ssl-images-amazon.com/images/I/71z6cD1znsL.jpg", "Healthy and delicious organic almonds", 15.99, "2025-02-01", 100, "Grocery", "Tesla"),
#     ("The Pragmatic Programmer", "https://m.media-amazon.com/images/I/41as+WafrFL._SX376_BO1,204,203,200_.jpg", "Bestselling programming classic", 44.00, "2020-01-01", 18, "Books", "Sony"),
#     ("Yoga Mat Pro", "https://cdn.shopify.com/s/files/1/0293/9277/products/yoga-mat-eco-black-1_1024x1024.jpg", "Eco-friendly yoga mat with grip", 55.50, "2023-08-08", 22, "Sports & Outdoors", "Adidas")
# ]

# # Step 1: Add categories and brands
# category_objs = {}
# brand_objs = {}

# for name in categories:
#     obj, _ = Category.objects.get_or_create(name=name)
#     category_objs[name] = obj

# for name in brands:
#     obj, _ = Brand.objects.get_or_create(name=name)
#     brand_objs[name] = obj

# # Step 2: Add products
# added = 0
# for name, image, desc, price, release, stock, cat, brand in products:
#     product, created = Product.objects.get_or_create(
#         name=name,
#         defaults={
#             "image": image,
#             "description": desc,
#             "price": price,
#             "release_date": release,
#             "stock": stock,
#             "category": category_objs[cat],
#             "brand": brand_objs[brand]
#         }
#     )
#     if created:
#         added += 1

# print(f"✅ დამატებულია {added} ახალი პროდუქტი ბაზაში.")


import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'online_store.settings')
django.setup()

from shop.models import Product

image_updates = {
    "iPhone 15 Pro": "https://arabcomputers.com.sa/wp-content/uploads/2023/09/iPhone_15_Pro_Natural_Titanium_PDP_Image_Position-1__en-ME.jpg",
    "Galaxy S23 Ultra": "https://igalaxy.nl/cdn/shop/files/samsung-galaxy-s23-ultra-1tb-zwart-5g.png?v=1718276799",
    "LG OLED TV 55": "https://alta.ge/images/detailed/297/638931-Product-1-I-638170238403708099_-_Copy_-_Copy_lenp-p4.webp",
    "Sony WH-1000XM5": "https://s3.zoommer.ge/zoommer-images/thumbs/0168812_sony-wh-1000xm5-wireless-noise-canceling-stereo-headset-black_550.jpeg",
    "Nike Air Max": "https://i5.walmartimages.com/seo/Nike-Air-Max-270-Mens-Casual-Shoes-Black-Anthracite-White-ah8050-002_1966979c-b224-4ea7-8025-df596194568d.8587ee80fb71955ce05135c5f6bbaca1.jpeg",
    "Adidas Hoodie": "https://refstore.co.uk/cdn/shop/files/98d74-h57512_app_photo_front_white.jpg?v=1703269052",
    "IKEA Billy Bookcase": "https://www.ikea.com/sa/en/images/products/billy-bookcase-white__0850382_pe656847_s5.jpg",
    "L’Oréal Face Cream": "https://m.media-amazon.com/images/I/51-2OljLHoL.jpg",
    "Hasbro Monopoly": "https://corners.ge/wp-content/uploads/2021/04/Monopoly.jpg",
    "Tesla Car Vacuum": "https://m.media-amazon.com/images/I/71bNplNvJEL.jpg",
    "Organic Almonds 1kg": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5kS_6FCVo2GyCt8hvSq-9gRlPg7vLzthzPQ&s",
    "The Pragmatic Programmer": "https://images-na.ssl-images-amazon.com/images/I/71f1jieYHNL._AC_UL600_SR600,600_.jpg",
    "Yoga Mat Pro": "https://www.manduka.com/cdn/shop/files/111011D20-MATS-PRO71-EARTH-04.jpg?v=1742938628&width=871"
}

updated_count = 0

for name, new_url in image_updates.items():
    product = Product.objects.filter(name=name).first()
    if product:
        product.image = new_url
        product.save()
        updated_count += 1
    else:
        print(f"❌ '{name}' not found in the database.")

print(f"✅ {updated_count} ფოტოს ლინკი განახლდა წარმატებით.")
