from rest_framework.routers import DefaultRouter

from .products import ProductViewSet
from .cart import CartViewSet, CartItemViewSet
from .order import OrderViewSet
from .reviews import ReviewViewSet

router = DefaultRouter()
router.register(r'products', ProductViewSet, basename='products')
router.register(r'cart', CartViewSet, basename='cart')
router.register(r'cart-items', CartItemViewSet, basename='cart-items')
router.register(r'orders', OrderViewSet, basename='orders')
router.register(r'reviews', ReviewViewSet, basename='reviews')

urlpatterns = router.urls
