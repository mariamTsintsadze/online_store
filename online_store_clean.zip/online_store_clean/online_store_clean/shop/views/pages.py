from django.shortcuts import render
from django.conf import settings
from django.http import HttpResponse
import os

def store_view(request):
    return render(request, 'store.html')


def cart_view(request):
    return render(request, 'cart.html')


def product_detail_view(request, pk):
    return render(request, 'product_detail.html')
