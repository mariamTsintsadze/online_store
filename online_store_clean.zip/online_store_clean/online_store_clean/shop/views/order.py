from rest_framework import viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from shop.models import Order, OrderItem, Cart, CartItem
from shop.serializers import OrderSerializer

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]

@api_view(['POST']) 
@permission_classes([IsAuthenticated])
def checkout(request):
    cart, _ = Cart.objects.get_or_create(user=request.user)
    items = CartItem.objects.filter(cart=cart)
    if not items.exists():
        return Response({'error': 'Cart is empty'}, status=400)

    total = sum(item.product.price * item.quantity for item in items)
    order = Order.objects.create(user=request.user, total_price=total)

    for item in items:
        OrderItem.objects.create(
            order=order,
            product=item.product,
            quantity=item.quantity,
            price=item.product.price
        )
        product = item.product
        product.stock -= item.quantity
        product.save()

    items.delete()
    return Response({'message': 'Order created successfully'})
