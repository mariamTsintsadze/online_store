from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login
from django import forms
from django.contrib import messages
import re

class CustomUserCreationForm(UserCreationForm):
    def clean_password2(self):
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Passwords do not match.")
        if len(password2) < 8 or \
           not re.search(r'[A-Z]', password2) or \
           not re.search(r'[a-z]', password2) or \
           not re.search(r'\d', password2) or \
           not re.search(r'[\W_]', password2):
            raise forms.ValidationError("Password must include uppercase, lowercase, number, symbol and be at least 8 characters long.")
        return password2

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            messages.success(request, '✅ Successfully logged in!')
            return redirect('/')
        else:
            messages.error(request, '❌ Invalid username or password')
    return render(request, 'login.html')

def custom_register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, '✅ Successfully registered and logged in!')
            return redirect('/')
        else:
            messages.error(request, '❌ Registration failed. Please check the form.')
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})
