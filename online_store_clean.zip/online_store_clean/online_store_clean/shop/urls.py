from django.urls import path, include
from .views import pages, auth, user, order
from django.contrib.auth import views as auth_views
from .views.api import urlpatterns as api_urlpatterns

urlpatterns = [
    path('', pages.store_view, name='store'),
    path('cart/', pages.cart_view, name='cart'),
    path('product/<int:pk>/', pages.product_detail_view, name='product_detail'),
    path('login/', auth.login_view, name='login'),
    path('register/', auth.custom_register, name='register'),
    path('api/cart-summary/', user.cart_summary),
    path('api/user/', user.user_status),
    path('api/checkout/', order.checkout),
    path('logout/', auth_views.LogoutView.as_view(next_page='/'), name='logout'),
    path('api/', include(api_urlpatterns)),  
]
